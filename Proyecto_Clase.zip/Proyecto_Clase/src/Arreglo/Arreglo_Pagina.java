package Arreglo;

import java.util.ArrayList;
import Final.Pagina_Principal;

public class Arreglo_Pagina {

	private ArrayList<Pagina_Principal>arreglo;
	
	public Arreglo_Pagina() {
		arreglo = new ArrayList<Pagina_Principal>();
		
	}
	
	public void adicionar (Pagina_Principal p) {
		arreglo.add(p);
	}
	public Pagina_Principal obtener (int position) {
		return arreglo.get(position);
	}
	public int tama�o() {
		return arreglo.size();
	}
}
