package Final;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;



public class Bienvenida extends JFrame{
	
	private JPanel panel;
	private JTextField texto1;
	private JLabel area,imagen1;
	private JButton boton,boton1;
	private ImageIcon imagen,imagen2;
	private Icon variable;
	private Image variable1;
	
	
	public Bienvenida() {
		this.setBounds(500, 250, 700, 500);
//		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setTitle("Bienvenido al banco");
		
//		Image variable1 = new ImageIcon(getClass().getResource("Bienvenido.JPG")).getImage();
//		setIconImage(variable1);
		
//		Image icon = new ImageIcon(getClass().getResource("Bienvenido.JPG")).getImage();
//        setIconImage(icon);
		

	
        IniciarComponentes();
	}
	
	public void IniciarComponentes() {
		ColocarPanel();
		ColocarTexto();
		ColocarBoton();
		ColocarBoton1();
		ColocarImagen();
	}
	public void ColocarPanel() {
		panel = new JPanel();
	//	panel.setLayout(new FlowLayout());
		panel.setLayout(null);
		panel.setBackground(Color.WHITE);
		this.add(panel);
	}
	public void ColocarTexto() {
		area = new JLabel();
		area.setBounds(230, 20, 300, 20);
		area.setText("Bienvenido al banco ANRC");
		area.setFont(new Font("arial",4,20));
		panel.add(area);

	}
	public void ColocarBoton() {
		boton = new JButton();
		boton.setBounds(120, 390, 150, 30);
		boton.setText("Ya tengo cuenta");
		panel.add(boton);
		
		ActionListener acboton = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Iniciar_sesion inicio = new Iniciar_sesion();
				inicio.setVisible(true);
				
			}
			
		};
		boton.addActionListener(acboton);
	}
	public void ColocarBoton1() {
		boton1 = new JButton();
		boton1.setText("Registrarme");
		boton1.setBounds(400, 390, 150, 30);
		panel.add(boton1);
		ActionListener acboton1 = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				Registro re = new Registro();
				re.setVisible(true);
			}
			
		};
		boton1.addActionListener(acboton1);
	}
	public void ColocarImagen() {
		imagen = new ImageIcon("Imagenes/Bienvenido.JPG");
		imagen1 = new JLabel(imagen);
		imagen1.setBounds(20,60, 650, 300);
		imagen1.setIcon(new ImageIcon (imagen.getImage().getScaledInstance(imagen1.getWidth(), imagen1.getHeight(), Image.SCALE_SMOOTH)));
		panel.add(imagen1);
	}
	
	
	

}
