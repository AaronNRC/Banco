package Final;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Credito extends JFrame {
	private JPanel panel;
	private JTextField texto,texto1,texto2,texto3;
	private JLabel area,area1,area2,area3,area4,area5,imagenI;
	private JButton boton,boton1;
	private JComboBox caja; 
	private int a;
	private ImageIcon imagen;
	
	
	public Credito() {
		this.setBounds(500, 250, 500, 300);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setTitle("Credito");
		IniciarComponentes();
	}
	public void IniciarComponentes() {
		 ColocarPanel();
		 ColocarTexto();
		 IngresarValor();
		 CantidadMeses();
		 IngresarMeses();
		 ColocarInteres();
		 ColocarTotal();
		 ColocarAtras();
		 ColocarImagen();
		 ColocarBoton();

		 
	}
	public void ColocarPanel() {
		 panel = new JPanel();
		 panel.setLayout(null);
		 this.add(panel); 
	}
	
	public void ColocarTexto() {
		area = new JLabel();
		area.setText("Valor del Credito: ");
		area.setBounds(10, 10, 200, 50);
		panel.add(area);
	}
	public void IngresarValor() {
		texto = new JTextField();
		texto.setBounds(120, 20, 60, 30);
		panel.add(texto);
	}

	
	public void CantidadMeses() {
		area1 = new JLabel();
		area1.setText("Ingrese la cantidad de meses: ");
		area1.setBounds(10,80,200,50);
		panel.add(area1);
	}
	
	public void IngresarMeses() {
		texto1 = new JTextField();
		texto1.setBounds(180, 90, 60, 30);
		panel.add(texto1);
	}
	public void Operacion() {

	}
	public void ColocarInteres() {
		area2 = new JLabel();
		area2.setText("Importante: El banco maneja una tasa de interes del 27.72%");
		area2.setBounds(10, 150, 500, 50);
		panel.add(area2);
	}
	
	public void ColocarTotal() {
		area3 = new JLabel();
		area3.setText("El Total del prestamo ser� de: " + texto.getText());
		area3.setBounds(10, 300, 200, 50);
		panel.add(area3);
	}
	 public void ColocarAtras() {
			JButton boton2 = new JButton();
			boton2.setBounds(400,220, 70, 30);
			boton2.setText("Atras");
			panel.add(boton2);
			
			ActionListener atras = new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					Inicio inicio = new Inicio();
					inicio.setVisible(true);
				}
				
			};
			boton2.addActionListener(atras);
		}
		public void ColocarBoton() {
			boton = new JButton();
			boton.setBounds(10, 210, 100, 50);
			boton.setText("Calcular");
			panel.add(boton);
			
			area3 = new JLabel();
			area3.setBounds(110, 205, 500, 50);
			panel.add(area3);	
			
			ActionListener prestamo1 = new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					
					area3.setText("     El Total del Credito ser� de: " );
					
					
				}
			};
			boton.addActionListener(prestamo1);
		}
	 public void ColocarImagen() {
		 imagen = new ImageIcon("Credito.PNG");
		 imagenI = new JLabel(imagen);
		 imagenI.setBounds(250, 10, 220, 150);
		 imagenI.setIcon(new ImageIcon(imagen.getImage().getScaledInstance(imagenI.getWidth(), imagenI.getHeight(), Image.SCALE_SMOOTH)));
		 panel.add(imagenI);
	 }
	
	/*public void MostrarResultado() {
		texto2 = new JTextField();
		texto2.setBounds(200, 220, 100, 50);
		texto2= (texto.getText())*(texto1.getText());
		panel.add(texto1);
	}
	*/
	
}
