package Final;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Datos extends JFrame{
	
	private JPanel panel;
	private JTextField mensaje,mensaje1,mensaje2;
	private JLabel texto,imagen1,texto1,texto2,texto3,imagen2;
	private JButton boton2;
	private JComboBox caja; 
	private JTable tabla;
	private JRadioButton radio,radio1;
	private ButtonGroup grupo;
	private ImageIcon imagen,imagen3;
	
	
	public Datos() {
		this.setTitle("Datos");
		this.setBounds(500, 300, 300, 300);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		IniciarComponentes();
	}

	public void IniciarComponentes() {
		ColocarPanel();
		ColocarNombre();
		ColocarCedula();
		ColocarSexo();
		ColocarCuenta();
		ColocarImagen1();
		ColocarImagen();
		ColocarAtras();

	}
	
	public void ColocarPanel() {
		panel = new JPanel();
		panel.setLayout(null);
		this.add(panel);
	}
	
	public void ColocarNombre() {
		texto = new JLabel();
		texto.setText("Nombre: Aaron Nicolas Ramirez ");
		texto.setBounds(10,20,300,40);
		panel.add(texto);
	}
	public void ColocarCedula () {
		texto1 = new JLabel();
		texto1.setText("Cedula: 1018698745 ");
		texto1.setBounds(10,50,300,40);
		panel.add(texto1);
	}
	public void ColocarSexo () {
		texto2 = new JLabel();
		texto2.setText("Genero: Masculino ");
		texto2.setBounds(10,80,300,40);
		panel.add(texto2);
	}
	public void ColocarCuenta () {
		texto2 = new JLabel();
		texto2.setText("Cuenta: Ahorros ");
		texto2.setBounds(10,110,300,40);
		panel.add(texto2);
	}
	
	public void ColocarImagen() {
		imagen = new ImageIcon("Imagenes/Fondo1.JPG");
		imagen1 = new JLabel(imagen);
		imagen1.setBounds(0,0, 300, 300);
		imagen1.setIcon(new ImageIcon (imagen.getImage().getScaledInstance(imagen1.getWidth(), imagen1.getHeight(), Image.SCALE_SMOOTH)));
		panel.add(imagen1);
	}
	public void ColocarImagen1() {
		imagen3 = new ImageIcon("Imagenes/Perfil.JPG");
		imagen2 = new JLabel(imagen3);
		imagen2.setBounds(150,60, 120, 60);
		imagen2.setIcon(new ImageIcon (imagen3.getImage().getScaledInstance(imagen2.getWidth(), imagen2.getHeight(), Image.SCALE_SMOOTH)));
		panel.add(imagen2);
	}
	public void ColocarAtras() {
		JButton boton2 = new JButton();
		boton2.setBounds(205,220, 70, 30);
		boton2.setText("Atras");
		panel.add(boton2);
		
		ActionListener atras = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Inicio inicio = new Inicio();
				inicio.setVisible(true);
			}
			
		};
		boton2.addActionListener(atras);
	}
	
	
	
}
