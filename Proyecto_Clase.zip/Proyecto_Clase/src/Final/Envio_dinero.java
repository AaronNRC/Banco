package Final;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class Envio_dinero extends JFrame{
	private JPanel panel;
	private JTextField texto,texto1,texto2,texto3;
	private JLabel area,area1,area2,area3,area4,area5,imagen4;
	private JButton boton,boton1;
	private JComboBox caja; 
	private ButtonGroup grupo;
	private JRadioButton radio,radio1;
	private int a;	
	private ImageIcon imagen,imagen3;
	
	
	public Envio_dinero() {
		this.setBounds(500, 250, 600, 400);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setTitle("Enviar dinero");
		IniciarComponentes();
	}
	public void IniciarComponentes() {
		 ColocarPanel();
		 ColocarTexto();
		 ColocarDocumento();
		 IngresarValor();	
		 ColocarInteres();
		 ColocarBoton();
		 ColocarInteres1();
		 ColocarRadioEdad();
		 ColocarBoton1();
		 ColocarImagen();
		 ColocarAtras();

		 
	}
	public void ColocarPanel() {
		 panel = new JPanel();
		 panel.setLayout(null);
		 panel.setBackground(Color.WHITE);
		 this.add(panel); 
	}
	
	public void ColocarTexto() {
		area = new JLabel();
		area.setText("A que persona desea enviarle el dinero: ");
		area.setBounds(10, 10, 250, 50);
		panel.add(area);
	}
	 private void ColocarDocumento() {
		 String[] documento = {"Seleccione ","Pap�","Mam� ","Ti�","Novia"};
		 caja = new JComboBox(documento);
		 caja.setBounds(240,26,300,20);
		 panel.add(caja);
		 }
	public void ColocarInteres() {
		area2 = new JLabel();
		area2.setText("Ingrese el monto a enviar:  $");
		area2.setBounds(10, 70, 500, 50);			
		panel.add(area2);
	}
	public void IngresarValor() {
		texto = new JTextField();
		texto.setBounds(180, 82, 100, 30);
		panel.add(texto);
	}
	public void ColocarInteres1() {
		area3 = new JLabel();
		area3.setText("�Desea guardar el contacto como frecuente?");
		area3.setBounds(10, 130, 500, 50);			
		panel.add(area3);
	}
	 private void ColocarRadioEdad() {
			radio = new JRadioButton("Si",true);
			radio.setBounds(320, 130, 100, 50);
			radio.setBackground(Color.white);
//			radio.setEnabled(false);
			panel.add(radio);
		 
			radio1 = new JRadioButton("No",true);
			radio1.setBounds(420, 130, 100, 50);
			radio1.setBackground(Color.white);
			panel.add(radio1);
			
			grupo = new ButtonGroup();
			grupo.add(radio);
			grupo.add(radio1);
	 }
	 public void ColocarBoton() {
			boton = new JButton();
			boton.setBounds(20, 190, 150, 30);
			boton.setText("Enviar");
			ImageIcon imagen = new ImageIcon("Enviar_di.PNG");
			boton.setIcon(new ImageIcon(imagen.getImage().getScaledInstance(boton.getWidth(), boton.getHeight(), Image.SCALE_AREA_AVERAGING)));

			panel.add(boton);
			
			ActionListener acboton = new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
				
					
				}
				
			};
			boton.addActionListener(acboton);
		}
	 
	 public void ColocarBoton1() {
			boton1 = new JButton();
			boton1.setBounds(350, 190, 150, 30);
			boton1.setText("Cancelar");
			ImageIcon imagen = new ImageIcon("Cancelar.JPG");
			boton1.setIcon(new ImageIcon(imagen.getImage().getScaledInstance(boton1.getWidth(), boton1.getHeight(), Image.SCALE_AREA_AVERAGING)));

			panel.add(boton1);
			
			ActionListener acboton = new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					Envio_dinero env = new Envio_dinero();
					env.setVisible(true);
					
				}
				
			};
			boton1.addActionListener(acboton);
		}
	 
		public void ColocarImagen() {
			imagen3 = new ImageIcon("enviar_di.JPG");
			imagen4 = new JLabel(imagen);
			imagen4.setBounds(80,240, 400, 120);
			imagen4.setIcon(new ImageIcon (imagen3.getImage().getScaledInstance(imagen4.getWidth(), imagen4.getHeight(), Image.SCALE_SMOOTH)));
			panel.add(imagen4);
		}
		public void ColocarAtras() {
			JButton boton2 = new JButton();
			boton2.setBounds(510,330, 70, 30);
			boton2.setText("Atras");
			panel.add(boton2);
			
			ActionListener atras = new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					Inicio inicio = new Inicio();
					inicio.setVisible(true);
				}
				
			};
			boton2.addActionListener(atras);
		}

}
