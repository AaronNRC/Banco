package Final;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Iniciar_sesion extends JFrame{
	
	private JPanel panel;
	private JTextField texto,texto1;
	private JLabel area,area1,area2,imagen1;
	private JButton boton,boton1;
	private JComboBox caja; 
	private ImageIcon imagen;
	
	public Iniciar_sesion() {
		this.setBounds(700, 250, 250, 300);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setTitle("Iniciar sesi�n");
		IniciarComponentes();
	}
	public void IniciarComponentes() {
		 ColocarPanel();
		 ColocarImagen();
		 ColocarTexto();
		 ColocarLista();
		 ColocarDocumento();
		 IngresarDocumento();
		 ColocarContrase�a();
		 InsertarContrase�a();
		 ColocarBoton();
		 ColocarBoton1();

		 
	}
	public void ColocarPanel() {
		 panel = new JPanel();
		 panel.setLayout(new FlowLayout());
		 panel.setBackground(Color.WHITE);
 		this.add(panel); 
	}
	
	public void ColocarTexto() {
		area = new JLabel();
		area.setText("Seleccione su tipo de documento");
		panel.add(area);
	}
	
	public void ColocarLista() {
		String [] documento = {"Seleccione documento","C�dula Ciudadania","C�dula Extranjer�a","Tarjeta de identidad ","Permiso especial de permanencia"};
		caja = new JComboBox(documento);
		panel.add(caja);
	}
	
	public void ColocarDocumento() {
		area1 = new JLabel();
		area1.setText("Ingrese su documento");
		panel.add(area1);
	}
	
	public void IngresarDocumento() {
		texto = new JTextField(20);
		panel.add(texto);
	}
	
	public void ColocarContrase�a() {
		area2 = new JLabel();
		area2.setText("Ingrese la contrase�a");
		panel.add(area2);
	}
	
	public void InsertarContrase�a() {
		texto1 = new JTextField(20);
		panel.add(texto1);
	}
	
	public void ColocarBoton() {
		boton = new JButton();
		boton.setText("Ingresar");
		panel.add(boton);
		
		ActionListener ingresar = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Inicio nuevo = new Inicio();
				nuevo.setVisible(true);
				
			}
	};
	boton.addActionListener(ingresar);
	}
	public void ColocarBoton1() {
		boton1 = new JButton();
		boton1.setText("Registrarme");
		panel.add(boton1);
		
		ActionListener Registro = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Registro re = new Registro();
				re.setVisible(true);
			}
	};
	boton1.addActionListener(Registro);
	}
	public void ColocarImagen() {
		imagen = new ImageIcon("Imagenes/Usuario1.JPG");
		imagen1 = new JLabel(imagen);
		imagen1.setBounds(0,0, 200, 70);
		imagen1.setIcon(new ImageIcon (imagen.getImage().getScaledInstance(imagen1.getWidth(), imagen1.getHeight(), Image.SCALE_SMOOTH)));
		panel.add(imagen1);
	}
	
}
