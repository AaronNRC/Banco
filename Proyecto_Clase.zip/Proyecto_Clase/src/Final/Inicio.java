package Final;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class Inicio extends JFrame{
	
	
	private JPanel panel;
	private JTextField texto,texto1;
	private JLabel text,envio_di,text2,color;
	private JButton boton,boton1,prestamo,enviar_di,datos,credito,tarjeta,extracto;
	private JComboBox caja; 
	private JTable tabla;
	private String [][]datos1={{"20200115","Uber","$18000","Colombia"},
							{"20200125","Rappi","$20000","Colombia"},
							{"20201326","HBO","$25000","Colombia"},
							{"20200314","Microsoft","$14000","Colombia"},
							{"20200315","didi","$8000","Colombia"},
							{"20200316","Retiro","$200000","Colombia"},
							{"20200328","Pago","$36000","Colombia"},
							{"20200405","Retiro","$40000","Colombia"},
							{"20200125","Rappi","$20000","Colombia"},
							{"20201326","HBO","$25000","Colombia"},
							{"20200314","Microsoft","$14000","Colombia"},
							{"20200315","didi","$8000","Colombia"},
							{"20200316","Retiro","$200000","Colombia"},
							{"20200328","Pago","$36000","Colombia"},
							{"20200405","Retiro","$40000","Colombia"},
							{"20200408","Amazon","$14000","Colombia"},
							{"20200420","Mercado Libre","$80000","Colombia"},
							{"20200522","Amazon","$100000","Colombia"},
							{"20200524","HBO","$30000","Colombia"},
							{"20200614","Uber","$33400","Colombia"},};
		
	public String [] titulo = {"fecha","Movimiento","Monto ","Nacionalidad"};
	
	public Inicio() {
		this.setBounds(400, 200, 750, 530);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setTitle("Cuenta");
		IniciarComponentes();
	}
	public void IniciarComponentes() {
		 ColocarPanel();	
		 ColocarTexto();
		 ColocarTexto1();
		 ColocarPrestamo();
		 ColocarEnvio();
		 ColocarCredito();
		 ColocarModificarDatos();
		 ColocarTC();
		 ColocarExtracto();
		 tabla();
		 ColocarAtras();
		 ColocarColor();
	}
	public void ColocarPanel() {
		 panel = new JPanel();
		 panel.setLayout(null);
		 panel.setBackground(Color.WHITE);
		this.add(panel);  
	}
	
	public void ColocarTexto() {
		text = new JLabel();
		text.setText("Mi cuenta");
		text.setFont(new Font("arial black",Font.PLAIN,25));
		text.setBounds(300, 0, 800, 50);
		panel.add(text);
	}
	public void ColocarTexto1() {
		text2 = new JLabel();
		text2.setText("Movimientos");
		text2.setBounds(350, 50, 800, 50);
		text2.setFont(new Font("arial black",Font.PLAIN,35));
		panel.add(text2);
	}
	
	public void ColocarPrestamo() {
		
		prestamo = new JButton();
		prestamo.setText("Prestamo");
		prestamo.setBounds(10, 50, 200, 60);
		panel.add(prestamo);	
		
		ActionListener Registro = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Prestamo pres = new Prestamo();
				pres.setVisible(true);
			}
	};
	prestamo.addActionListener(Registro);
	}
	
	public void ColocarEnvio() {
		
		enviar_di = new JButton();
		enviar_di.setText("Enviar dinero");
		enviar_di.setBounds(10, 120, 200, 60);
		panel.add(enviar_di);	
	
		ActionListener Registro = new ActionListener() {
	
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Envio_dinero env = new Envio_dinero();
				env.setVisible(true);
			}
	};
	enviar_di.addActionListener(Registro);
	}
	public void ColocarCredito() {
		
		credito = new JButton();
		credito.setText("Soliciar cr�dito");
		credito.setBounds(10, 190, 200, 60);
		panel.add(credito);	
		
		ActionListener Registro1 = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Solicitar_cre credito = new Solicitar_cre();
				credito.setVisible(true);
			}
	};
	credito.addActionListener(Registro1);
	}
	public void ColocarModificarDatos() {
		
		datos = new JButton();
		datos.setText("Datos");
		datos.setBounds(10, 260, 200, 60);
		panel.add(datos);	
		
		ActionListener Registro2 = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Datos dat = new Datos();
				dat.setVisible(true);
			}
	};
	datos.addActionListener(Registro2);
	}
	public void ColocarTC() {
		
		tarjeta = new JButton();
		tarjeta.setText("Tarjeta de cr�dito");
		tarjeta.setBounds(10, 330, 200, 60);
		panel.add(tarjeta);	
		
		ActionListener Registro3 = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Envio_dinero env = new Envio_dinero();
				env.setVisible(true);
			}
	};
	tarjeta.addActionListener(Registro3);
	}
	public void ColocarExtracto() {
		
		extracto = new JButton();
		extracto.setText("Solicitar extracto");
		extracto.setBounds(10, 400, 200, 70);
		panel.add(extracto);
		
		ActionListener Registro4 = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Solicitar_ext sol = new Solicitar_ext();
				sol.setVisible(true);
			}
	};
	extracto.addActionListener(Registro4);
	}
	public void tabla() {

		tabla = new JTable(datos1,titulo);
		JScrollPane Js = new JScrollPane(tabla);
		Js.setBounds(220, 100, 500, 350);
		Js.setPreferredSize(new Dimension(400,500));
		panel.add(Js);
	}
	public void ColocarAtras() {
			JButton boton2 = new JButton();
			boton2.setBounds(690,40, 35, 45);
			boton2.setText("Salir");
			ImageIcon imagen = new ImageIcon("Salir.JPG");
			boton2.setIcon(new ImageIcon(imagen.getImage().getScaledInstance(boton2.getWidth(), boton2.getHeight(), Image.SCALE_AREA_AVERAGING)));

			panel.add(boton2);
			
			ActionListener atras = new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					Bienvenida inicio = new Bienvenida();
					inicio.setVisible(true);
				}
				
			};
			boton2.addActionListener(atras);
		}
	public void ColocarColor() {
		ImageIcon rojo = new ImageIcon("Rojo.JPG");
		color = new JLabel(rojo);
		color.setBounds(5, 20, 209, 460);
		color.setIcon(new ImageIcon(rojo.getImage().getScaledInstance(color.getWidth(), color.getHeight(), Image.SCALE_SMOOTH)));
		panel.add(color);
	}
	 
		 
	
	
}
