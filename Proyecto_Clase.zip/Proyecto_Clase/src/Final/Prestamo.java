package Final;

import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Prestamo extends JFrame{
	
	private JPanel panel;
	private JTextField texto,texto1,texto2,texto3;
	private JLabel area,area1,area2,area3,area4,area5,imagen1;
	private JButton boton,boton1;
	private JComboBox caja; 
	private int a;
	private ImageIcon imagen;
	
	
	public Prestamo() {
		this.setBounds(500, 250, 380, 500);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setTitle("Prestamo");
		IniciarComponentes();
	}
	public void IniciarComponentes() {
		 ColocarPanel();
		 ColocarTexto();
		 IngresarValor();
		 CantidadMeses();
		 IngresarMeses();
		 ColocarInteres();
		 ColocarBoton();
		 ColocarAtras();
		 ColocarImagen();

		 
	}
	public void ColocarPanel() {
		 panel = new JPanel();
		 panel.setLayout(null);
		 this.add(panel); 
	}
	
	public void ColocarTexto() {
		area = new JLabel();
		area.setText("Valor del pr�stamo:   $");
		area.setBounds(10, 10, 200, 50);
		panel.add(area);
	}		

	public void IngresarValor() {
		texto = new JTextField();
		texto.setBounds(140, 25, 100, 30);
		panel.add(texto);
	}

	
	public void CantidadMeses() {
		area1 = new JLabel();
		area1.setText("Ingrese la cantidad de meses:  $");
		area1.setBounds(10,80,200,50);
		panel.add(area1);
	}
	
	public void IngresarMeses() {
		texto1 = new JTextField();
		texto1.setBounds(195, 95, 100, 30);
		panel.add(texto1);
	}
	public void Operacion() {

	}
	public void ColocarInteres() {
		area2 = new JLabel();
		area2.setText("Importante: El banco maneja una tasa de interes del 27.72%");
		area2.setBounds(10, 150, 500, 50);
		panel.add(area2);
	}
	
	public void ColocarBoton() {
		boton = new JButton();
		boton.setBounds(10, 210, 100, 50);
		boton.setText("Calcular");
		panel.add(boton);
		
		area3 = new JLabel();
		area3.setBounds(110, 210, 500, 50);
		panel.add(area3);	
		
		ActionListener prestamo1 = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				area3.setText("     El Total del prestamo ser� de: " );
				
				
			}
		};
		boton.addActionListener(prestamo1);


	}
	public void ColocarAtras() {
		JButton boton2 = new JButton();
		boton2.setBounds(290,430, 70, 30);
		boton2.setText("Atras");
		panel.add(boton2);
		
		ActionListener atras = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Inicio inicio = new Inicio();
				inicio.setVisible(true);
			}
			
		};
		boton2.addActionListener(atras);
	}
	public void ColocarImagen() {
		imagen = new ImageIcon("Prestamo.JPG");
		imagen1 = new JLabel(imagen);
		imagen1.setBounds(5,270, 350, 150);
		imagen1.setIcon(new ImageIcon (imagen.getImage().getScaledInstance(imagen1.getWidth(), imagen1.getHeight(), Image.SCALE_SMOOTH)));
		panel.add(imagen1);
	}
}
