package Final;

public class Principal {

	public static void main ( String [] args) {
	
//		Registro re = new Registro();
//		re.setVisible(true);
		Bienvenida hola = new Bienvenida();
		hola.setVisible(true);
//		pru.setVisible(true);
//		Inicio nue = new Inicio();
//		nue.setVisible(true);
//		Prestamo pres = new Prestamo();
//		pres.setVisible(true);
//		Solicitar_cre solicitar = new Solicitar_cre();
//		solicitar.setVisible(true);
//		Solicitar_ext solicitar = new Solicitar_ext();
//		solicitar.setVisible(true);
//		Datos datos = new Datos();
//		datos.setVisible(true);
//		Credito cre = new Credito();
//		cre.setVisible(true);
//		Envio_dinero env = new Envio_dinero();
//		env.setVisible(true);
//		Iniciar_sesion ini = new Iniciar_sesion();
//		ini.setVisible(true);
		
	}
}
