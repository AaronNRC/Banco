package Final;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;


public class Prueba extends JFrame{
		
		private JPanel panel;
		private JTextField texto,texto1;
		private JLabel area,area1,area2,area3;
		private JButton boton,boton1;
		private JComboBox caja; 
		private JTabbedPane tab1,tab2;
		
		public Prueba() {
			this.setBounds(500, 250, 250, 300);
			this.setDefaultCloseOperation(EXIT_ON_CLOSE);
			this.setTitle("Iniciar sesi�n");
			IniciarComponentes();
		}
		public void IniciarComponentes() {
			ColocarTab();
			 ColocarPanel();
			 ColocarDocumento();
			 IngresarDocumento();
			 segundop();
			 
		}

		public void ColocarTab() {
			tab1 = new JTabbedPane();
	 		this.add(tab1); 
		}
		
		public void ColocarPanel() {
			panel = new JPanel();
			panel.setLayout(new FlowLayout());
//	 		this.add(panel); 
			tab1.add(panel);

	 		
	 		
		}
		
		
		public void ColocarDocumento() {
			area1 = new JLabel();
			area1.setText("Ingrese su documento");
			panel.add(area1);
		}
		
		public void IngresarDocumento() {
			texto = new JTextField(20);
			panel.add(texto);
		}
		

		
		public void segundop() {
			JPanel segundo = new JPanel();
			area3 = new JLabel();
			area3.setText("Seleccione su tipo de documento");
			panel.add(area3);
			tab1.add(segundo);
			
		}
		
	
	
}
