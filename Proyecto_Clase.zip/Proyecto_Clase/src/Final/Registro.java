package Final;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;


public class Registro extends JFrame{

	private JPanel panel;
	private JLabel texto,texto1,texto2,texto3,texto4,label,label1,label2,label3,label4,label5;
	private JTextField area,area1,area2,area3;
	private JButton boton,boton1;
	private JRadioButton radio,radio1,radio2,radio3;
	private ButtonGroup grupo;
	
	
	public Registro() {
		this.setBounds(500, 400, 300, 300);
		this.setTitle("Datos para la cuenta");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		IniciarComponentes();
	}


	public void IniciarComponentes() {
		ColocarPanel();
		ColocarTexto();
		ColocarArea();
		ColocarTexto1();
		ColocarArea1();
		ColocarTexto3();
		ColocarArea3();
		ColocarTexto2();
		ColocarRadioB();
		ColocarTexto4();
		ColocarRadioB1();
		ColocaBoton();
		ColocarBoton1();
	}
	
	public void ColocarPanel() {
		panel = new JPanel();
//		panel.setLayout(null);
		panel.setLayout(new FlowLayout());
		this.add(panel);
	}
	
	public void ColocarTexto() {
		texto = new JLabel();
		texto.setText("Digite su nombre");
		panel.add(texto);
	}
	public void ColocarArea() {
		area = new JTextField(10);
		panel.add(area);
	}
	public void ColocarTexto1() {
		texto1 = new JLabel();
		texto1.setText("Ingrese su n�mero de documento");
		panel.add(texto1);
	}
	public void ColocarArea1() {
		area1 = new JTextField(5);
		panel.add(area1);
	}
	public void ColocarTexto3() {
		texto3 = new JLabel();
		texto3.setText("Digite su correo electronico");
		panel.add(texto3);
	}
	public void ColocarArea3() {
		area3 = new JTextField(10);
		panel.add(area3);
	}
	public void ColocarTexto2() {
		texto2 = new JLabel();
		texto2.setText("Cual es su genero");
		panel.add(texto2);
	}
	
	public void ColocarRadioB() {
		radio = new JRadioButton("Masculino",true);
		panel.add(radio);
		
		radio1 = new JRadioButton("Femenino",false);
		panel.add(radio1);
		
		
		grupo = new ButtonGroup();
		grupo.add(radio);
		grupo.add(radio1);
	
		
	}
	public void ColocarTexto4() {
		texto4 = new JLabel();
		texto4.setText("�Es usted mayor de edad?");
		panel.add(texto4);
	}
	public void ColocarRadioB1() {
		radio2 = new JRadioButton("si",false);
		panel.add(radio2);
		
		radio3 = new JRadioButton("no",false);
		panel.add(radio3);
		
		
		grupo = new ButtonGroup();
		grupo.add(radio2);
		grupo.add(radio3);
	
		
	}
	
	public void ColocaBoton() {
		boton= new JButton();
		boton.setText("Click");
		panel.add(boton);
		
		label = new JLabel();
		panel.add(label);
		
		label1 = new JLabel();
		panel.add(label1);
		
		label2 = new JLabel();
		panel.add(label2);
		
		label3 = new JLabel();
		panel.add(label3);
		
		ActionListener oyente1 = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				 
				Iniciar_sesion nuevo = new Iniciar_sesion();
				nuevo.setVisible(true);
			}
		
/*			
			public String genero() {
				String genero;
				 if (radio.isSelected()==true) {
					 genero="Mascullino";
				 }else {
					 genero="Femenino";
				 }
				return genero;
			}
			
			public String mayorE() {
				String mayorE;
				if (radio2.isSelected()==true) {
					
					mayorE="Si";
					
				}else {
					mayorE="No";
				}
				
				return mayorE;
			}*/
		};
		boton.addActionListener(oyente1);
				
	}
	
	public void ColocarBoton1() {
		
		boton1= new JButton();
		boton1.setText("Atras");
		panel.add(boton1);
		
		ActionListener Bienvenido = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				 Bienvenida hola = new Bienvenida();
				 hola.setVisible(true);
			}
		};
		boton1.addActionListener(Bienvenido);

		
	}
	
	


}
