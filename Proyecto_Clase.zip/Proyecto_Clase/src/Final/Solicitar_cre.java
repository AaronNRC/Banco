package Final;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Solicitar_cre extends JFrame{
	
	private JPanel panel;
	private JTextField texto,texto1;
	private JLabel text,Edad,CajaTex,CajaTex1,CajaTex2;
	private JButton boton,boton1,prestamo,enviar_di,datos,credito,tarjeta,extracto;
	private JComboBox caja; 
	private JTable tabla;
	private JRadioButton radio,radio1;
	private ButtonGroup grupo;
	private JTextArea textarea;
	
	
	public Solicitar_cre() {
		this.setBounds(500,300,500, 300);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setTitle("Solicitar Credito");
		IniciarComponentes();
	}
	 private void IniciarComponentes() {
		 ColocarPanel();
		 ColocarTexto();
		 ColocarCuadro1();
		 ColocarEdad();
		 ColocarRadioEdad();
		 ColocarCajaTexto();
		 ColocarDocumento();
		 ColocarCajaTexto1();
		 ColocarAreaTexto();
		 ColocarAtras();
	 }
	 
	 private void ColocarPanel() {
		 panel = new JPanel();
		 panel.setLayout(null);
		 this.add(panel);
		 }
	 private void ColocarTexto() {
		text = new JLabel();
		text.setText("Ingresos mensuales: ");
		text.setBounds(10, 10, 200, 50);
		panel.add(text);
	 }
	 private void ColocarCuadro1() {
		 texto = new JTextField();
		 texto.setBounds(150, 25, 100, 20);
		 panel.add(texto);
	 }
	 private void ColocarEdad() {
		Edad = new JLabel();
		Edad.setText("�Eres mayor de edad? ");
		Edad.setBounds(10, 50, 300, 50);
		panel.add(Edad);
	 }
	 private void ColocarRadioEdad() {
			radio = new JRadioButton("Si",true);
			radio.setBounds(150, 50, 100, 50);
//			radio.setEnabled(false);
			panel.add(radio);
		 
			radio1 = new JRadioButton("No",true);
			radio1.setBounds(250, 50, 100, 50);
			panel.add(radio1);
			
			grupo = new ButtonGroup();
			grupo.add(radio);
			grupo.add(radio1);
	 }
	 private void ColocarCajaTexto() {
		 CajaTex = new JLabel();
		 CajaTex.setText("Indique tipo de documento:");
		 CajaTex.setBounds(10, 90, 500, 50);
		 panel.add(CajaTex);
		  }
		 
	 private void ColocarDocumento() {
	 String[] documento = {"Seleccione documento","Cedula de ciudadania","Tarjeta de identidad ","Cedula de extranjero","Documento residente"};
	 caja = new JComboBox(documento);
	 caja.setBounds(170,105,300,20);
	 panel.add(caja);
	 }
	 private void ColocarCajaTexto1() {
		CajaTex1 = new JLabel();
		CajaTex1.setText("�Para que desea utilizar este cr�dito?");
		CajaTex1.setBounds(10, 130, 450, 50);
		panel.add(CajaTex1);
	 }
	 private void ColocarAreaTexto() {
		textarea = new JTextArea();
		textarea.setBounds(10, 175, 300, 80);
		textarea.setText("Ingresa ac� la raz�n...");
		panel.add(textarea);
	 }
	 public void ColocarAtras() {
			JButton boton2 = new JButton();
			boton2.setBounds(400,220, 70, 30);
			boton2.setText("Atras");
			panel.add(boton2);
			
			ActionListener atras = new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					Inicio inicio = new Inicio();
					inicio.setVisible(true);
				}
				
			};
			boton2.addActionListener(atras);
		}
		 
	  
	 
		 
		 
	 
	 
	
}
