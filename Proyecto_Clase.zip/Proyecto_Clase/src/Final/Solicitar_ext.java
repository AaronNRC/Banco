package Final;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Solicitar_ext extends JFrame{


	private JPanel panel;
	private JTextField mensaje,mensaje1,mensaje2;
	private JLabel texto,texto1,texto2,texto3;
	private JButton boton,boton1,prestamo,enviar_di,datos,credito,tarjeta,extracto;
	private JComboBox caja; 
	private JTable tabla;
	private JRadioButton radio,radio1;
	private ButtonGroup grupo;
	private JTextArea textarea;
	
	
	public Solicitar_ext(){
		this.setBounds(500, 250, 500, 300);
		this.setTitle("Extractos");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		IniciarComponentes();
		
	}
	public void IniciarComponentes() {
		ColocarPanel();
		ColocarTexto1();
		ColocarCuenta();
		ColocarFechaInicial();
		ColocarFechaFinal();
		FechaInicio();
		FechaFinal();
		ColocarBoton();
		ColocarAtras();
	}
	
	public void ColocarPanel() {
		panel = new JPanel();
		panel.setLayout(null);
		this.add(panel);
	}
	public void ColocarTexto1() {
		texto = new JLabel();
		texto.setBounds(10,10,300,50);
		texto.setText("De que cuenta desea solicitar el extracto: ");
		panel.add(texto);
	}
	public void ColocarCuenta() {
		String [] tipo = {"Seleccionar cuenta" , "Tarjeta de debito terminada en 5878" , "Tarjeta de cr�dito termianda en 4783"};
		caja = new JComboBox(tipo);
		caja.setBounds(250, 25, 220, 20);
		panel.add(caja);
	}
	public void ColocarFechaInicial() {
		texto1 = new JLabel();
		texto1.setBounds(10, 75, 200, 50);
		texto1.setText("Fecha de inicio: ");
		panel.add(texto1);
	}
	public void ColocarFechaFinal() {
		texto2 = new JLabel();
		texto2.setBounds(10, 130, 200, 50);
		texto2.setText("Fecha Final: ");
		panel.add(texto2);
	}
	public void FechaInicio() {
		mensaje = new JTextField();
		mensaje.setBounds(100,80,100,30);
		panel.add(mensaje);
	}
	public void FechaFinal() {
		mensaje = new JTextField();
		mensaje.setBounds(90,14	0,100,30);
		panel.add(mensaje);
	}
	public void ColocarBoton() {
		boton = new JButton();
		boton.setBounds(250,70,190,100);
		boton.setText("Descargar reporte");
		ImageIcon imagen = new ImageIcon("PDF.JPG");
		boton.setIcon(new ImageIcon(imagen.getImage().getScaledInstance(boton.getWidth(), boton.getHeight(), Image.SCALE_AREA_AVERAGING)));
		panel.add(boton);
		
		texto3 = new JLabel();
		texto3.setBounds(210,160,500,40);
		texto3.setFont(new Font("arial",1,10));
		panel.add(texto3);
		
		
		ActionListener descargar = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				texto3.setText("Descargando reporte en breve estar� en su correo"); 
			}
			
		};
		boton.addActionListener(descargar);
	}
	
	public void ColocarAtras() {
		JButton boton2 = new JButton();
		boton2.setBounds(400,220, 70, 30);
		boton2.setText("Atras");
		panel.add(boton2);
		
		ActionListener atras = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Inicio inicio = new Inicio();
				inicio.setVisible(true);
			}
			
		};
		boton2.addActionListener(atras);
	}
	
	
	
	
}
