module Final {
	requires java.desktop;
}